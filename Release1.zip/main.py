from dataclasses import dataclass, field
from typing import Union, Literal, Optional, Type, Generator, Any, Callable
import time
import itertools
import threading
from collections import deque

# ====================== ФАЙЛОВАЯ СИСТЕМА ======================

@dataclass
class File:
    name: str
    content: str = ""

@dataclass
class Folder:
    name: str
    files: list[Union["File", "Folder", "ProgramFile"]] = field(default_factory=list)


@dataclass
class ProgramFile:
    """Специальный файл, который хранит класс программы"""
    name: str
    program_class: Type["Program"]


class FileSystem:
    def __init__(self, kernel: "Kernel" = None):
        self.root = Folder(name="/")
        self.kernel = kernel  # нужно для run_program

    def _resolve(self, path: str) -> tuple[Folder, str]:
        parts = [p for p in path.strip("/").split("/") if p]
        if not parts:
            raise ValueError("Некорректный путь")

        current = self.root
        for part in parts[:-1]:
            found = None
            for item in current.files:
                if isinstance(item, Folder) and item.name == part:
                    found = item
                    break
            if found is None:
                raise FileNotFoundError(f"Папка не найдена: {part}")
            current = found

        return current, parts[-1]

    def create_folder(self, path: str) -> None:
        parent, name = self._resolve(path)
        for item in parent.files:
            if item.name == name:
                raise FileExistsError(f"Уже существует: {name}")
        parent.files.append(Folder(name=name))

    def open_file(self, path: str, mode: Literal["w", "r", "a"] = "r"):
        parent, name = self._resolve(path)

        file_obj = None
        for item in parent.files:
            if isinstance(item, File) and item.name == name:
                file_obj = item
                break

        if mode == "r":
            if file_obj is None:
                raise FileNotFoundError(f"Файл не найден: {path}")
            return FileHandle(file_obj, mode)

        if mode in ("w", "a"):
            if file_obj is None:
                file_obj = File(name=name)
                parent.files.append(file_obj)
            if mode == "w":
                file_obj.content = ""
            return FileHandle(file_obj, mode)

    def delete_file(self, path: str) -> None:
        parent, name = self._resolve(path)
        for i, item in enumerate(parent.files):
            if item.name == name and not isinstance(item, Folder):
                del parent.files[i]
                return
        raise FileNotFoundError(f"Файл не найден: {path}")

    def delete_folder(self, path: str) -> None:
        parent, name = self._resolve(path)
        for i, item in enumerate(parent.files):
            if item.name == name and isinstance(item, Folder):
                del parent.files[i]
                return
        raise FileNotFoundError(f"Файл не найден: {path}")

    def write_program(self, path: str, program: Type["Program"]) -> None:
        """Сохраняет класс программы в файловую систему"""
        parent, name = self._resolve(path)

        # Удаляем старый, если есть
        for i, item in enumerate(parent.files):
            if item.name == name:
                del parent.files[i]
                break

        parent.files.append(ProgramFile(name=name, program_class=program))

    def run_program(self, path: str) -> "IO":
        """Запускает программу из файловой системы и возвращает её IO"""
        parent, name = self._resolve(path)

        prog_file = None
        for item in parent.files:
            if isinstance(item, ProgramFile) and item.name == name:
                prog_file = item
                break

        if prog_file is None:
            raise FileNotFoundError(f"Программа не найдена: {path}")

        if self.kernel is None:
            raise RuntimeError("FileSystem не привязан к ядру")

        process = self.kernel.create_process(prog_file.program_class)
        return process.io

    def delete_program(self, path: str) -> None:
        """Удаляет программу"""
        parent, name = self._resolve(path)
        for i, item in enumerate(parent.files):
            if isinstance(item, ProgramFile) and item.name == name:
                del parent.files[i]
                return
        raise FileNotFoundError(f"Программа не найдена: {path}")

    def exists(self, path: str) -> bool:
        """Проверяет, существует ли что-либо по пути (файл, папка или программа)"""
        try:
            parent, name = self._resolve(path)
            for item in parent.files:
                if item.name == name:
                    return True
            return False
        except (FileNotFoundError, ValueError):
            return False

    def exists_folder(self, path: str) -> bool:
        """Проверяет, существует ли папка"""
        try:
            parent, name = self._resolve(path)
            for item in parent.files:
                if isinstance(item, Folder) and item.name == name:
                    return True
            return False
        except (FileNotFoundError, ValueError):
            return False

    def exists_file(self, path: str) -> bool:
        """Проверяет, существует ли обычный файл"""
        try:
            parent, name = self._resolve(path)
            for item in parent.files:
                if isinstance(item, File) and item.name == name:
                    return True
            return False
        except (FileNotFoundError, ValueError):
            return False

    def exists_program(self, path: str) -> bool:
        """Проверяет, существует ли программа"""
        try:
            parent, name = self._resolve(path)
            for item in parent.files:
                if isinstance(item, ProgramFile) and item.name == name:
                    return True
            return False
        except (FileNotFoundError, ValueError):
            return False

    def listfiles(self, path: str = "/") -> list[str]:
        """
        Возвращает список имён в указанной папке.
        Папки будут с '/', программы с '*'.
        """
        try:
            if path == "/" or path == "":
                folder = self.root
            else:
                parent, name = self._resolve(path)
                folder = None
                for item in parent.files:
                    if isinstance(item, Folder) and item.name == name:
                        folder = item
                        break
                if folder is None:
                    raise NotADirectoryError(f"{path} is not a directory")

            result = []
            for item in folder.files:
                if isinstance(item, Folder):
                    result.append(item.name + "/")
                elif hasattr(item, "program_class"):
                    result.append(item.name)
                else:
                    result.append(item.name)
            return result

        except Exception as e:
            raise FileNotFoundError(str(e))


class FileHandle:
    def __init__(self, file: File, mode: str):
        self.file = file
        self.mode = mode

    def read(self) -> str:
        if self.mode != "r":
            raise ValueError("Файл открыт не на чтение")
        return self.file.content

    def write(self, text: str) -> None:
        if self.mode == "r":
            raise ValueError("Файл открыт только на чтение")
        if self.mode == "w":
            self.file.content = text
        else:
            self.file.content += text

    def close(self):
        pass


# ====================== IO ПРОТОКОЛ ======================

class IO:
    def __init__(self):
        self._waiting = False
        self._request: Optional[str] = None
        self._expected_len: Optional[int] = None
        self._pending_data: Optional[str] = None

    def is_reading(self) -> bool:
        return self._waiting

    def read_line(self) -> Generator[None, str, str]:
        self._waiting = True
        self._request = "line"
        data = yield
        self._waiting = False
        self._request = None
        return data

    def read_len(self, length: int) -> Generator[None, str, str]:
        self._waiting = True
        self._request = "len"
        self._expected_len = length
        data = yield
        self._waiting = False
        self._request = None
        self._expected_len = None
        return data

    def send(self, data: str) -> None:
        self._pending_data = data

    def write(self, text: str) -> None:
        print(text, end="", flush=True)


# ====================== СОКЕТЫ ======================

class Socket:
    def __init__(self):
        self._buffer: deque[str] = deque()
        self._closed = False
        self._peer: Optional["Socket"] = None
        self._waiting = False
        self._pending_data: Optional[str] = None

    def _link(self, other: "Socket"):
        self._peer = other
        other._peer = self

    def send(self, data: str) -> None:
        if self._closed or self._peer is None or self._peer._closed:
            raise RuntimeError("Сокет закрыт")
        self._peer._buffer.append(data)

    def read(self) -> str:
        if self._buffer:
            return self._buffer.popleft()
        if self._closed or self._peer is None or self._peer._closed:
            return ""
        return ""

    def close(self) -> None:
        self._closed = True
        if self._peer:
            self._peer._closed = True

    def read_wait(self) -> Generator[None, None, str]:
        self._waiting = True
        while True:
            data = self.read()
            if data or self._closed or (self._peer and self._peer._closed):
                self._waiting = False
                return data
            yield


class ServerSocket:
    def __init__(self, port: int, kernel: "Kernel"):
        self.port = port
        self.kernel = kernel
        self._closed = False
        self._waiting_accept = False
        self._pending_client: Optional[Socket] = None

    def accept(self) -> Generator[None, None, Socket]:
        if self._closed:
            raise RuntimeError("Серверный сокет закрыт")

        self._waiting_accept = True
        while self._pending_client is None:
            if self._closed:
                self._waiting_accept = False
                raise RuntimeError("Серверный сокет закрыт")
            yield

        client_sock = self._pending_client
        self._pending_client = None
        self._waiting_accept = False
        return client_sock

    def close(self) -> None:
        self._closed = True
        if self.port in self.kernel._ports:
            del self.kernel._ports[self.port]


# ====================== ПРОГРАММЫ ======================

class Program:
    def __init__(self, syskernel: "Kernel", io: IO):
        self.syskernel = syskernel
        self.io = io
        self.pid: Optional[int] = None
        self.exit_code: Optional[int] = None
        self.finished = False
        self._gen: Optional[Generator] = None
        self.can_capture_input = False  # ← добавь эту строку

    def main(self) -> Generator[Any, Any, int]:
        raise NotImplementedError


class Init(Program):
    def main(self):
        self.io.write("PPlusOS on Python\n")
        self.io.write("Python-based kernel.\n")
        return 0


# ====================== ЯДРО ======================

class Kernel:
    def __init__(self):
        self.beat: float | int = 0.0
        self.running = True
        self.fs = FileSystem(self)          # передаём себя
        self.processes: list[Program] = []
        self._pid_counter = itertools.count(1)
        self._port_counter = itertools.count(10000)
        self._ports: dict[int, ServerSocket] = {}
        self.status: Literal['dead', 'recovery', 'ok', 'sleep'] = 'ok'

    def socket(self, type: Literal["client", "server"], port: int = 0) -> Union[Socket, ServerSocket]:
        if type == "server":
            if port == 0:
                while True:
                    port = next(self._port_counter)
                    if port not in self._ports:
                        break
            else:
                if port in self._ports:
                    raise OSError(f"Порт {port} уже занят")

            server = ServerSocket(port, self)
            self._ports[port] = server
            return server

        elif type == "client":
            if port == 0:
                raise ValueError("Клиенту нужно указать порт")
            if port not in self._ports:
                raise ConnectionRefusedError(f"Нет сервера на порту {port}")

            server = self._ports[port]
            if server._closed:
                raise ConnectionRefusedError(f"Сервер на порту {port} закрыт")

            client_sock = Socket()
            server_sock = Socket()
            client_sock._link(server_sock)

            server._pending_client = server_sock
            return client_sock

        else:
            raise ValueError("type должен быть 'client' или 'server'")

    def start_thread(self, function: Callable, args: tuple = (), kwargs: dict = None):
        if kwargs is None:
            kwargs = {}
        class Thread(Program):
            def main(self):
                nonlocal function
                yield from function(*args, **kwargs)
        self.create_process(Thread, False)

    def create_process(self, program_class: Type[Program], capture_input: bool = False) -> Program:
        io = IO()
        program = program_class(self, io)
        program.pid = next(self._pid_counter)
        program.can_capture_input = capture_input  # ← важно
        self.processes.append(program)

        gen = program.main()

        if not hasattr(gen, "__next__"):
            program.exit_code = gen
            program.finished = True
            return program

        program._gen = gen

        try:
            next(gen)
        except StopIteration as e:
            program.exit_code = e.value if e.value is not None else 0
            program.finished = True

        return program

    def _step_process(self, program: Program):
        if program.finished or program._gen is None:
            return

        io = program.io

        try:
            if io.is_reading():
                if io._pending_data is not None:
                    # Данные от родителя / write_arguments
                    data = io._pending_data
                    io._pending_data = None
                    program._gen.send(data)
                elif program.can_capture_input:
                    # Только главные процессы читают с клавиатуры
                    data = input()
                    program._gen.send(data)
                # иначе дочерний процесс просто ждёт send()
            else:
                next(program._gen)

        except StopIteration as e:
            program.exit_code = e.value if e.value is not None else 0
            program.finished = True

        except Exception as e:
            print(e)
            program.finished = True
            program.exit_code = 2



    def boot(self):
        self.create_process(Init)

        print("--- Ядро работает (Ctrl+C для выхода) ---\n")
        start = time.time()
        while self.running:
            self.beat = time.time()-start
            start = time.time()
            for proc in self.processes:
                if not proc.finished:
                    self._step_process(proc)
            time.sleep(0.05)

    def shutdown(self):
        print("\nОстановка ядра...")
        self.running = False

