from time import time
import datetime
from typing import Generator, Any
import pygame as pg
pg.init()
from main import Kernel, Program, Folder, IO
import os
import base64
import json

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
HOME_FAF_PATH = os.path.join(SCRIPT_DIR, 'home.faf')
def load_home():
    """Загрузить /home из home.faf (с диска или из FS)"""
    b64 = None
    # 1) с реального диска
    try:
        with open('home.faf', 'r', encoding='utf-8') as f:
            b64 = f.read().strip()
    except FileNotFoundError:
        pass
    # 2) или из виртуальной FS
    if not b64:
        try:
            if kernel.fs.exists_file('/home.faf'):
                b64 = kernel.fs.open_file('/home.faf', 'r').read().strip()
        except Exception:
            pass
    if not b64:
        print('No home.faf — fresh /home')
        return

    try:
        raw = base64.b64decode(b64.encode('ascii')).decode('utf-8')
        obj = json.loads(raw)
        if obj.get('type') != 'faf':
            print('home.faf invalid')
            return
        faf = FafCommand(kernel, IO())  # временный экземпляр только для _restore
        # очищать /home не обязательно — _restore перезапишет файлы
        faf._restore(kernel.fs, '/home', obj['root'])
        # положить копию и в виртуальную FS
        kernel.fs.open_file('/home.faf', 'w').write(b64)
        print('Loaded /home from home.faf')
    except Exception as e:
        print(f'load home error: {e}')
def _restore_node(fs, path, node):
    if node.get('type') == 'file':
        parent = '/'.join(path.strip('/').split('/')[:-1])
        if parent:
            try:
                fs.create_folder('/' + parent)
            except Exception:
                pass
        fs.open_file(path, 'w').write(node.get('content', ''))
    elif node.get('type') == 'dir':
        try:
            if path not in ('/', '/home'):
                fs.create_folder(path)
            elif path == '/home' and not fs.exists_folder('/home'):
                fs.create_folder('/home')
        except Exception:
            pass
        for ch in node.get('children', []):
            name = ch.get('name', 'unknown')
            if path == '/':
                child = '/' + name
            else:
                child = path.rstrip('/') + '/' + name
            _restore_node(fs, child, ch)
kernel = Kernel()
print('Generating base file system...')
kernel.fs.create_folder('/etc')
kernel.fs.open_file('/etc/motd','w').write('PPlusOS Console\n')
kernel.fs.open_file('/etc/sysname','w').write('PPlus')
kernel.fs.open_file('/etc/hostname','w').write('PPlus PC')
kernel.fs.create_folder('/bin')
kernel.fs.create_folder('/tmp')
kernel.fs.create_folder('/home')
kernel.fs.open_file('/README.txt','w').write("""Welcome to PPlusOS! PPlusOS is an Python-based OS. It has a kernel, and PPUi (PPlusUi). PPlus means "PythonPlus". Instead of command arguments, it sends data to the program. """)
kernel.fs.create_folder('/log')
kernel.fs.open_file('/etc/ppm.conf', 'w').write('repo=https://raw.githubusercontent.com/PykitYT/PPlusOS/main\n')
print('Base file system done.')
load_home()   # ← сюда
print('Base file system done.')
def current_time():
    return datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S')
def create_program(name, program):
    kernel.fs.write_program('/bin/'+name, program)
def write_arguments(io: IO, args: list[str], kernel=None):
    args = list(args)
    while args:
        if kernel is not None:
            process = None
            for p in kernel.processes:
                if p.io is io:
                    process = p
                    break
            if process is None or process.finished:
                return
        if io.is_reading():
            io.send(args.pop(0))
        yield
class PPLUSConsole(Program):
    def main(self):
        yield
        io = self.io
        fs = self.syskernel.fs
        io.write('\033[2J\033[H\n')
        yield
        io.write(fs.open_file('/etc/motd', 'r').read())
        while True:
            io.write('* ')
            cmd = yield from io.read_line()
            cmd = cmd.strip()
            if not cmd:
                continue
            args = cmd.split()[1:]
            cmd = cmd.split()[0]
            if cmd == 'exit':
                return 0
            if cmd == '_r':
                io.write('Restart system.')
                for _ in range(10): yield
                fs.run_program('/bin/res')
                return 0
            if cmd == '_h':
                program_io = fs.run_program('/bin/help')
                for _ in range(10):
                    yield
                io.write(str(program_io.read_line()).splitlines()[0]+'\n')
                continue
            if not fs.exists_program('/bin/' + cmd):
                io.write(f'console: not exist {cmd}\n')
                continue
            program_io = fs.run_program('/bin/' + cmd)
            yield from write_arguments(program_io,args,self.syskernel)
            now = datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S')
            while True:
                process = None
                for p in self.syskernel.processes:
                    if p.io is program_io:
                        process = p
                        break
                if process is None or process.finished:
                    break
                if program_io.is_reading():
                    data = yield from io.read_line()
                    program_io.send(data)
                else:
                    yield
            fs.open_file('/log/' + datetime.datetime.now().strftime('%Y.%m.%d %H:%M:%S') + '.log', 'w').write(f'{now} * {cmd} {' '.join(args)}')
class TreeCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        def print_tree(folder, prefix="", is_last=True):
            connector = "└── " if is_last else "├── "
            io.write(prefix + connector + folder.name + "/\n")
            new_prefix = prefix + ("    " if is_last else "│   ")
            items = folder.files
            for i, item in enumerate(items):
                last = (i == len(items) - 1)
                if isinstance(item, Folder):
                    print_tree(item, new_prefix, last)
                else:
                    connector = "└── " if last else "├── "
                    # Показываем тип
                    if hasattr(item, "program_class"):
                        name = item.name + "  (program)"
                    else:
                        name = item.name
                    io.write(new_prefix + connector + name + "\n")
        io.write("Main Directory\n")
        print_tree(fs.root, "", True)
        return 0
class WriteFileCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        io.write('wf\npath = ')
        path = yield from io.read_line()
        io.write('data = ')
        data = yield from io.read_line()
        fs.open_file(path=path, mode='w').write(text=data)
        io.write('done\n')
        return 0
class ReadFileCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        io.write('path = ')
        path = yield from io.read_line()
        data = fs.open_file(path=path, mode='r').read()
        io.write('data: ' + data + '\n')
        return 0


class LsCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        io.write('path (empty = /): ')
        path = yield from io.read_line()
        path = path.strip() or '/'

        try:
            if path == '/':
                folder = fs.root
            else:
                parent, name = fs._resolve(path)
                folder = None
                for item in parent.files:
                    if isinstance(item, Folder) and item.name == name:
                        folder = item
                        break
                if folder is None:
                    io.write('ls: not a directory\n')
                    return 1

            for item in folder.files:
                if isinstance(item, Folder):
                    io.write(f'{item.name}/\n')
                elif hasattr(item, 'program_class'):
                    io.write(f'{item.name}*\n')
                else:
                    io.write(f'{item.name}\n')
        except Exception as e:
            io.write(f'ls: {e}\n')
            return 1
        return 0


class MkdirCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        io.write('path = ')
        path = yield from io.read_line()
        try:
            fs.create_folder(path.strip())
            io.write('ok\n')
        except Exception as e:
            io.write(f'mkdir: {e}\n')
            return 1
        return 0


class RmCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        io.write('path = ')
        path = yield from io.read_line()
        path = path.strip()
        try:
            if fs.exists_program(path):
                fs.delete_program(path)
            elif fs.exists_folder(path):
                fs.delete_folder(path)
            elif fs.exists_file(path):
                fs.delete_file(path)
            else:
                io.write('rm: not found\n')
                return 1
            io.write('ok\n')
        except Exception as e:
            io.write(f'rm: {e}\n')
            return 1
        return 0


class ClearCommand(Program):
    def main(self):
        self.io.write('\033[2J\033[H\n')  # очистка экрана
        return 0


class EchoCommand(Program):
    def main(self):
        io = self.io
        io.write('text = ')
        text = yield from io.read_line()
        io.write(text + '\n')
        return 0


class HelpCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        output = ''
        for program in fs.listfiles('/bin'):
            output += program + ' '
        output += '\n'
        io.write(output)
        return 0

class PsCommand(Program):
    def main(self):
        io = self.io
        io.write(f'{"PID":<5} {"STATUS":<10} {"EXIT":<6} PROGRAM\n')
        for p in self.syskernel.processes:
            status = 'finished' if p.finished else 'running'
            name = p.__class__.__name__
            code = p.exit_code if p.exit_code is not None else '-'
            io.write(f'{p.pid:<5} {status:<10} {str(code):<6} {name}\n')
        return 0
class Python3Command(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        io.write("Python 3 (PPlusOS)\n")
        io.write("Type 'exit' or Ctrl+C logic via 'exit' to quit.\n")
        local_vars = {}
        while True:
            io.write(">>> ")
            line = yield from io.read_line()
            line = line.strip()
            if not line:
                continue
            if line in ("exit", "exit()", "quit", "quit()"):
                return 0
            try:
                try:
                    result = eval(line, {"__builtins__": __builtins__}, local_vars)
                    if result is not None:
                        io.write(repr(result) + "\n")
                except SyntaxError:
                    exec(line, {"__builtins__": __builtins__}, local_vars)
            except Exception as e:
                io.write(f"{type(e).__name__}: {e}\n")
        return 0
class PPUi(Program):
    def main(self):
        import pygame as pg
        pg.init()
        info = pg.display.Info()
        WIDTH, HEIGHT = info.current_w, info.current_h
        sc = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption("PPlusOS Console")
        clk = pg.time.Clock()
        font = pg.font.SysFont("consolas", 20) or pg.font.SysFont(None, 22)
        pg.display.toggle_fullscreen()
        pg.mouse.set_visible(False)

        line_h = font.get_height() + 2
        # сколько строк реально влезает (оставляем 1 строку под ввод)
        max_lines = max(1, (HEIGHT - 20) // line_h - 1)
        # сколько символов влезает по ширине
        char_w = font.size("M")[0] or 10
        max_chars = max(10, (WIDTH - 20) // char_w)

        lines = []
        buf = ""
        pending = ""

        def add_line(text):
            # режем длинные строки, чтобы влезали по ширине
            text = str(text)
            if not text:
                lines.append("")
            else:
                while text:
                    lines.append(text[:max_chars])
                    text = text[max_chars:]
            # лимит по высоте окна
            while len(lines) > max_lines:
                lines.pop(0)

        def gui_write(text):
            nonlocal pending
            pending += str(text)
            while "\n" in pending:
                line, pending = pending.split("\n", 1)
                add_line(line)

        original_write = IO.write

        def patched_write(self, text):
            gui_write(text)

        IO.write = patched_write

        console = self.syskernel.create_process(PPLUSConsole, capture_input=False)
        # после set_mode / font
        splash_img = None
        try:
            splash_img = pg.image.load('data/splash.jpg').convert()
            splash_img = pg.transform.smoothscale(splash_img, (WIDTH, HEIGHT))
        except Exception:
            pass

        t0 = time()
        while time() - t0 < 5.0:
            for e in pg.event.get():
                if e.type == pg.QUIT or (e.type == pg.KEYDOWN and e.key == pg.K_ESCAPE):
                    pg.display.quit()
                    return 0
                if e.type == pg.KEYDOWN:
                    t0 = 0
            if splash_img:
                sc.blit(splash_img, (0, 0))
            else:
                sc.fill((8, 10, 18))
                title = font.render("PPlusOS", True, (120, 220, 255))
                sc.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
            pg.display.flip()
            clk.tick(30)
            yield
        run = True
        recovery_image = pg.transform.scale(pg.image.load('data/recovery.jpg'), sc.get_size())
        dead_image = pg.transform.scale(pg.image.load('data/systemdead.jpg'), sc.get_size())
        try:
            while run and not console.finished:
                for e in pg.event.get():
                    if e.type == pg.QUIT or (e.type == pg.KEYDOWN and e.key == pg.K_ESCAPE):
                        run = False
                    elif e.type == pg.KEYDOWN:
                        if e.key == pg.K_RETURN:
                            if console.io.is_reading():
                                console.io.send(buf)
                            gui_write(buf + "\n")
                            buf = ""
                        elif e.key == pg.K_BACKSPACE:
                            buf = buf[:-1]
                        elif e.type == pg.KEYDOWN:
                            mods = pg.key.get_mods()
                            ctrl = bool(mods & pg.KMOD_CTRL)

                            if e.key == pg.K_RETURN:
                                if console.io.is_reading():
                                    console.io.send(buf)
                                gui_write(buf + "\n")
                                buf = ""

                            elif e.key == pg.K_BACKSPACE:
                                if not ctrl:
                                    buf = buf[:-1]

                            elif e.key == pg.K_TAB:
                                buf += "\t"


                            elif ctrl and e.key == pg.K_ESCAPE:
                                run = False

                            elif ctrl:
                                # Ctrl+буква → "_u", "_r", "_q", ...
                                name = pg.key.name(e.key)  # 'u', 'r', 'g', ...
                                if len(name) == 1 and name.isalpha():
                                    hot = "_" + name.lower()
                                    if console.io.is_reading():
                                        console.io.send(hot)  # сразу как целая «строка»
                                    gui_write(hot + "\n")
                                    buf = ""
                                # Ctrl+цифра → "_3"
                                elif name.isdigit():
                                    hot = "_" + name
                                    if console.io.is_reading():
                                        console.io.send(hot)
                                    gui_write(hot + "\n")
                                    buf = ""

                            elif e.unicode and e.unicode.isprintable():
                                buf += e.unicode

                sc.fill((0,0,0))
                y = 10
                for line in lines:
                    if '\033[2J\033[H' in line:
                        lines = []
                for line in lines:
                    line = line.replace("\t","│")
                    sc.blit(font.render(line, True, (255,255,255)), (10, y))
                    y += line_h

                # текущий ввод (тоже обрезаем)
                current = (pending + buf + "█")[-max_chars:]
                sc.blit(font.render(current.replace("\t", "│"), True, (255,255,255)), (10, y))
                if self.syskernel.status == 'recovery':
                    sc.blit(recovery_image, (0, 0))
                elif self.syskernel.status == 'dead':
                    sc.blit(dead_image, (0, 0))
                pg.display.flip()
                clk.tick(30)
                yield
        finally:
            IO.write = original_write
            pg.display.quit()

        return 0
class WaitCommand(Program):
    def main(self):
        io = self.io
        start = time()
        try:
            io.write('secs = ')
            secs = yield from io.read_line()
            count = float(secs)
            io.write('...\n')
        except:
            io.write('sl error. invalid float value\n')
            return 1
        while True:
            yield
            if time() - start > count:
                break
        return 0
class BoardcastSocket(Program):
    def main(self):
        io = self.io
        io.write("text = ")
        text = yield from io.read_line()
        io.write("port = ")
        try:
            port = int((yield from io.read_line()).strip())
        except Exception:
            io.write("invalid port number\n")
            return 1
        class BroadcastThread(Program):
            def main(self):
                try:
                    sock = self.syskernel.socket("server", port)
                except OSError as e:
                    return 1
                while True:
                    cli = yield from sock.accept()
                    try:
                        cli.send(text)
                    finally:
                        cli.close()
        self.syskernel.create_process(BroadcastThread, False)
        io.write(f"broadcast on {port}\n")
        return 0
class RawReadSocket(Program):
    def main(self):
        self.io.write('port = ')
        try:
            port = yield from self.io.read_line()
            port = int(port)
        except Exception:
            self.io.write('invalid port number\n')
            return 1
        try:
            sock = self.syskernel.socket('client', port)
        except ConnectionRefusedError:
            self.io.write('Error while connecting.\n')
            return 1
        for _ in range(10): pass
        data = yield from sock.read_wait()
        self.io.write((data or '') + '\n')
        sock.close()
        return 0
class StopTaskCommand(Program):
    def main(self):
        self.io.write('pid = ')
        try:
            pid = yield from self.io.read_line()
            pid = int(pid)
        except:
            self.io.write('invalid pid number\n')
            return 1
        finished = False
        for process in self.syskernel.processes:
            if process.pid == pid:
                process.finished = True
                self.io.write('ok\n')
                finished = True
        if not finished:
            self.io.write('cannot find pid\n')
        return 0
class Restart(Program):
    def main(self):
        self.io.write('\033[2J\033[H\n')
        for process in self.syskernel.processes:
            if process == self:
                continue
            process.finished = True
        for process in self.syskernel.processes:
            if process == self:
                continue
            self.syskernel.processes.pop(self.syskernel.processes.index(process))
        self.syskernel.create_process(PPUi, False)
        kernel.create_process(BackgroundRecoveryThing, capture_input=False)
        return 0
class PPtcp(Program):
    def main(self):
        import socket
        import threading
        import inspect
        from queue import Empty, Queue

        HOST, PORT = "0.0.0.0", 2525
        stop = {"flag": False}

        sessions = {}
        sessions_lock = threading.Lock()
        next_id = {"n": 1}
        io_map = {}  # id(io) -> send_fn

        original_write = IO.write
        original_io_init = IO.__init__
        original_run = self.syskernel.fs.run_program
        original_cp = self.syskernel.create_process

        def find_session_from_stack():
            for fr in inspect.stack():
                obj = fr.frame.f_locals.get("self")
                if isinstance(obj, PPLUSConsole):
                    with sessions_lock:
                        for s in sessions.values():
                            if s["console"] is obj:
                                return s
            return None

        def bind_io(io_obj, send_fn):
            io_map[id(io_obj)] = send_fn

        def patched_write(self_io, text):
            fn = io_map.get(id(self_io))
            if fn:
                fn(text)
                return
            # на всякий случай — привязать по стеку и отправить
            s = find_session_from_stack()
            if s is not None:
                bind_io(self_io, s["send"])
                s["send"](text)

        def patched_io_init(self_io, *a, **k):
            original_io_init(self_io, *a, **k)
            s = find_session_from_stack()
            if s is not None:
                bind_io(self_io, s["send"])

        IO.write = patched_write
        IO.__init__ = patched_io_init

        def run_program_hook(path):
            io = original_run(path)
            s = find_session_from_stack()
            if s is not None:
                bind_io(io, s["send"])
            return io

        self.syskernel.fs.run_program = run_program_hook

        def make_session(cli, addr):
            sid = next_id["n"]
            next_id["n"] += 1
            key_q = Queue()

            session = {
                "id": sid,
                "cli": cli,
                "addr": addr,
                "key_q": key_q,
                "console": None,
                "line_buf": "",
                "alive": True,
                "send": None,
            }

            def send_tcp(text: str):
                if not session["alive"]:
                    return
                try:
                    cli.sendall(str(text).replace("\n", "\r\n").encode("utf-8", errors="replace"))
                except OSError:
                    session["alive"] = False

            session["send"] = send_tcp

            # консоль создаём уже с session в dict (для find_session_from_stack)
            with sessions_lock:
                sessions[sid] = session

            console = original_cp(PPLUSConsole, capture_input=False)
            session["console"] = console
            bind_io(console.io, send_tcp)

            send_tcp(f"PPlusOS session #{sid}\r\n")
            return session

        def client_reader(session):
            cli = session["cli"]
            cli.settimeout(0.05)
            while not stop["flag"] and session["alive"]:
                try:
                    chunk = cli.recv(256)
                    if not chunk:
                        break
                    for ch in chunk.decode("utf-8", errors="replace"):
                        session["key_q"].put(ch)
                except socket.timeout:
                    continue
                except OSError:
                    break
            session["alive"] = False
            try:
                cli.close()
            except OSError:
                pass

        def server_thread():
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((HOST, PORT))
            srv.listen(10)
            srv.settimeout(0.5)
            while not stop["flag"]:
                try:
                    cli, addr = srv.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                session = make_session(cli, addr)
                threading.Thread(target=client_reader, args=(session,), daemon=True).start()
            try:
                srv.close()
            except OSError:
                pass

        threading.Thread(target=server_thread, daemon=True).start()

        try:
            while True:
                with sessions_lock:
                    items = list(sessions.items())

                for sid, s in items:
                    if not s["alive"] or (s["console"] and s["console"].finished):
                        s["alive"] = False
                        if s["console"]:
                            s["console"].finished = True
                        with sessions_lock:
                            sessions.pop(sid, None)
                        continue

                    cio = s["console"].io
                    while True:
                        try:
                            ch = s["key_q"].get_nowait()
                        except Empty:
                            break

                        if ch in ("\r", "\n"):
                            s["send"]("\r\n")
                            if cio.is_reading():
                                cio.send(s["line_buf"])
                            s["line_buf"] = ""
                        elif ch in ("\b", "\x7f"):
                            if s["line_buf"]:
                                s["line_buf"] = s["line_buf"][:-1]
                                s["send"]("\b \b")
                        elif ch.isprintable():
                            s["line_buf"] += ch
                            s["send"](ch)

                yield
        finally:
            stop["flag"] = True
            IO.write = original_write
            IO.__init__ = original_io_init
            self.syskernel.fs.run_program = original_run
            with sessions_lock:
                for s in sessions.values():
                    s["alive"] = False
                    if s["console"]:
                        s["console"].finished = True
                    try:
                        s["cli"].close()
                    except OSError:
                        pass
                sessions.clear()

        return 0
import base64
import json

class FafCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs

        io.write('mode (encode/decode) = ')
        mode = (yield from io.read_line()).strip().lower()
        io.write('src = ')
        src = (yield from io.read_line()).strip()
        io.write('dst = ')
        dst = (yield from io.read_line()).strip()

        if not src.startswith('/'):
            src = '/' + src
        if not dst.startswith('/'):
            dst = '/' + dst

        try:
            if mode == 'encode':
                data = self._collect(fs, src)
                raw = json.dumps({"type": "faf", "version": 1, "root": data}, ensure_ascii=False)
                b64 = base64.b64encode(raw.encode('utf-8')).decode('ascii')
                # создаём родительскую папку если нужно
                parent = '/'.join(dst.strip('/').split('/')[:-1])
                if parent:
                    try:
                        fs.create_folder('/' + parent)
                    except Exception:
                        pass
                fs.open_file(dst, 'w').write(b64)
                io.write('encoded ok\n')
                return 0

            elif mode == 'decode':
                b64 = fs.open_file(src, 'r').read().strip()
                raw = base64.b64decode(b64.encode('ascii')).decode('utf-8')
                obj = json.loads(raw)
                if obj.get('type') != 'faf':
                    io.write('not a faf file\n')
                    return 1
                self._restore(fs, dst, obj['root'])
                io.write('decoded ok\n')
                return 0
            else:
                io.write('use encode or decode\n')
                return 1
        except Exception as e:
            io.write(f'faf error: {e}\n')
            return 1

    def _collect(self, fs, path):
        """Собрать файл или папку в dict"""
        if fs.exists_file(path):
            return {"type": "file", "name": path.rstrip('/').split('/')[-1],
                    "content": fs.open_file(path, 'r').read()}
        if fs.exists_folder(path) or path == '/':
            name = '/' if path == '/' else path.rstrip('/').split('/')[-1]
            node = {"type": "dir", "name": name, "children": []}
            try:
                items = fs.listfiles(path)
            except Exception:
                items = []
            for item in items:
                # listfiles: 'name/' или 'name' или 'name*'
                pure = item.rstrip('/*')
                child_path = (path.rstrip('/') + '/' + pure) if path != '/' else '/' + pure
                if item.endswith('/') or fs.exists_folder(child_path):
                    node['children'].append(self._collect(fs, child_path))
                elif fs.exists_file(child_path):
                    node['children'].append(self._collect(fs, child_path))
                # программы (name*) можно пропустить или сохранить как метку
            return node
        raise FileNotFoundError(path)

    def _restore(self, fs, path, node):
        if node['type'] == 'file':
            parent = '/'.join(path.strip('/').split('/')[:-1])
            if parent:
                try:
                    fs.create_folder('/' + parent)
                except Exception:
                    pass
            fs.open_file(path, 'w').write(node.get('content', ''))
        elif node['type'] == 'dir':
            try:
                fs.create_folder(path)
            except Exception:
                pass
            for ch in node.get('children', []):
                child_path = (path.rstrip('/') + '/' + ch['name']) if path != '/' else '/' + ch['name']
                self._restore(fs, child_path, ch)
class NanoCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs

        io.write('file = ')
        path = (yield from io.read_line()).strip()
        if not path.startswith('/'):
            path = '/' + path

        lines = []
        # если файл есть — загрузить
        try:
            if fs.exists_file(path):
                content = fs.open_file(path, 'r').read()
                lines = content.split('\n')
                if lines and lines[-1] == '':
                    lines.pop()
                io.write(f'loaded {len(lines)} lines\n')
        except Exception:
            pass

        io.write('nano: type lines.  _+ edit  _p print  _w save  _q quit  _d delete\n')

        while True:
            io.write(f'{len(lines)+1}> ')
            line = yield from io.read_line()

            cmd = line.strip()

            if cmd in ('_+', '+_'):
                if not lines:
                    io.write('no lines\n')
                    continue
                for i, l in enumerate(lines, 1):
                    io.write(f'{i}: {l}\n')
                io.write('line # = ')
                try:
                    n = int((yield from io.read_line()).strip())
                    if not (1 <= n <= len(lines)):
                        io.write('bad number\n')
                        continue
                except Exception:
                    io.write('bad number\n')
                    continue
                io.write(f'{n}: {lines[n-1]}\n')
                io.write('new = ')
                new = yield from io.read_line()
                lines[n - 1] = new
                io.write('ok\n')
                continue

            if cmd == '_p':
                if not lines:
                    io.write('(empty)\n')
                for i, l in enumerate(lines, 1):
                    io.write(f'{i}: {l}\n')
                continue

            if cmd == '_d':
                if not lines:
                    io.write('no lines\n')
                    continue
                for i, l in enumerate(lines, 1):
                    io.write(f'{i}: {l}\n')
                io.write('delete # = ')
                try:
                    n = int((yield from io.read_line()).strip())
                    if 1 <= n <= len(lines):
                        lines.pop(n - 1)
                        io.write('deleted\n')
                    else:
                        io.write('bad number\n')
                except Exception:
                    io.write('bad number\n')
                continue

            if cmd == '_w':
                parent = '/'.join(path.strip('/').split('/')[:-1])
                if parent:
                    try:
                        fs.create_folder('/' + parent)
                    except Exception:
                        pass
                fs.open_file(path, 'w').write('\n'.join(lines) + ('\n' if lines else ''))
                io.write(f'saved {path} ({len(lines)} lines)\n')
                return 0

            if cmd == '_q':
                io.write('quit\n')
                return 0

            # обычная новая строка
            lines.append(line)
class SaveCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs
        try:
            # переиспользуем логику FAF
            faf = FafCommand(self.syskernel, io)
            data = faf._collect(fs, '/home')
            raw = json.dumps({"type": "faf", "version": 1, "root": data}, ensure_ascii=False)
            b64 = base64.b64encode(raw.encode('utf-8')).decode('ascii')
            fs.open_file('/home.faf', 'w').write(b64)

            # дополнительно — на реальный диск рядом со скриптом
            with open('home.faf', 'w', encoding='utf-8') as f:
                f.write(b64)

            io.write('saved /home -> home.faf\n')
            return 0
        except Exception as e:
            io.write(f'save error: {e}\n')
            return 1
class LoadCommand(Program):
    def main(self):
        io = self.io
        fs = self.syskernel.fs

        # --- 1. очистить /home в ВО ---
        try:
            parent, name = fs._resolve('/home')
            # name == 'home', parent == root
            for i, item in enumerate(list(parent.files)):
                if isinstance(item, Folder) and item.name == 'home':
                    parent.files[i] = Folder(name='home')  # пустая папка
                    break
            else:
                fs.create_folder('/home')
        except Exception as e:
            io.write(f'clear /home error: {e}\n')
            return 1

        # --- 2. прочитать home.faf с ГО ---
        if not os.path.isfile(HOME_FAF_PATH):
            io.write(f'not found: {HOME_FAF_PATH}\n')
            return 1

        try:
            with open(HOME_FAF_PATH, 'r', encoding='utf-8') as f:
                b64 = f.read().strip()
            raw = base64.b64decode(b64.encode('ascii')).decode('utf-8')
            obj = json.loads(raw)
            if obj.get('type') != 'faf':
                io.write('invalid faf\n')
                return 1
        except Exception as e:
            io.write(f'read error: {e}\n')
            return 1

        # --- 3. записать в ВО ---
        try:
            _restore_node(fs, '/home', obj['root'])
            fs.open_file('/home.faf', 'w').write(b64)
            io.write('loaded /home from disk home.faf\n')
            return 0
        except Exception as e:
            io.write(f'restore error: {e}\n')
            return 1
class DotPyCommand(Program):
    """Запуск .py скриптов из виртуальной FS: print/input/open → PPlusOS."""

    def main(self):
        import threading
        from queue import Queue, Empty

        io = self.io
        fs = self.syskernel.fs

        io.write('script = ')
        path = (yield from io.read_line()).strip()
        if not path.startswith('/'):
            path = '/' + path

        try:
            code = fs.open_file(path, 'r').read()
        except Exception as e:
            io.write(f'cannot read: {e}\n')
            return 1

        # ---------- VirtualFile ----------
        class VirtualFile:
            def __init__(self, path, mode):
                self.path = path
                self.mode = mode
                self._pos = 0
                self.closed = False

                if 'b' in mode:
                    raise ValueError('binary mode not supported in VFS')

                if 'r' in mode and 'w' not in mode and 'a' not in mode:
                    self._data = fs.open_file(path, 'r').read()
                elif 'w' in mode:
                    self._data = ''
                    parent = '/'.join(path.strip('/').split('/')[:-1])
                    if parent:
                        try:
                            fs.create_folder('/' + parent)
                        except Exception:
                            pass
                    fs.open_file(path, 'w').write('')
                elif 'a' in mode:
                    try:
                        self._data = fs.open_file(path, 'r').read()
                    except Exception:
                        self._data = ''
                    parent = '/'.join(path.strip('/').split('/')[:-1])
                    if parent:
                        try:
                            fs.create_folder('/' + parent)
                        except Exception:
                            pass
                    self._pos = len(self._data)
                else:
                    try:
                        self._data = fs.open_file(path, 'r').read()
                    except Exception:
                        self._data = ''

            def read(self, n=-1):
                if self.closed:
                    raise ValueError('closed file')
                if 'r' not in self.mode and '+' not in self.mode:
                    raise ValueError('not readable')
                if n is None or n < 0:
                    out = self._data[self._pos:]
                    self._pos = len(self._data)
                    return out
                out = self._data[self._pos:self._pos + n]
                self._pos += len(out)
                return out

            def readline(self, n=-1):
                if self._pos >= len(self._data):
                    return ''
                i = self._data.find('\n', self._pos)
                if i < 0:
                    line = self._data[self._pos:]
                    self._pos = len(self._data)
                else:
                    line = self._data[self._pos:i + 1]
                    self._pos = i + 1
                if n is not None and n >= 0:
                    line = line[:n]
                return line

            def readlines(self):
                lines = []
                while True:
                    line = self.readline()
                    if not line:
                        break
                    lines.append(line)
                return lines

            def write(self, text):
                if self.closed:
                    raise ValueError('closed file')
                if 'w' not in self.mode and 'a' not in self.mode and '+' not in self.mode:
                    raise ValueError('not writable')
                text = str(text)
                self._data = self._data[:self._pos] + text + self._data[self._pos:]
                self._pos += len(text)
                fs.open_file(self.path, 'w').write(self._data)
                return len(text)

            def writelines(self, lines):
                for line in lines:
                    self.write(line)

            def seek(self, pos, whence=0):
                if whence == 0:
                    self._pos = pos
                elif whence == 1:
                    self._pos += pos
                elif whence == 2:
                    self._pos = len(self._data) + pos
                self._pos = max(0, min(self._pos, len(self._data)))
                return self._pos

            def tell(self):
                return self._pos

            def flush(self):
                if 'w' in self.mode or 'a' in self.mode or '+' in self.mode:
                    fs.open_file(self.path, 'w').write(self._data)

            def close(self):
                if not self.closed:
                    self.flush()
                    self.closed = True

            def __enter__(self):
                return self

            def __exit__(self, *args):
                self.close()

            def __iter__(self):
                return self

            def __next__(self):
                line = self.readline()
                if not line:
                    raise StopIteration
                return line

        def vfs_open(file, mode='r', *args, **kwargs):
            p = str(file).strip()
            if not p.startswith('/'):
                p = '/' + p
            return VirtualFile(p, mode)

        def fake_print(*args, sep=' ', end='\n', **kwargs):
            io.write(sep.join(str(a) for a in args) + end)

        # ---------- input через поток + очередь ----------
        req_q = Queue()   # prompt
        ans_q = Queue()   # ответ
        done = {'ok': False, 'err': None}

        def blocking_input(prompt=''):
            req_q.put(str(prompt) if prompt is not None else '')
            return ans_q.get()

        def runner():
            loc = {
                'print': fake_print,
                'input': blocking_input,
                'open': vfs_open,
                '__name__': '__main__',
            }
            try:
                exec(code, {'__builtins__': __builtins__}, loc)
                done['ok'] = True
            except Exception as e:
                done['err'] = e

        t = threading.Thread(target=runner, daemon=True)
        t.start()

        while t.is_alive() or not req_q.empty():
            try:
                prompt = req_q.get_nowait()
            except Empty:
                yield
                continue

            if prompt:
                io.write(prompt)
            answer = yield from io.read_line()
            ans_q.put(answer)

        t.join(timeout=0.5)

        if done['err'] is not None:
            io.write(f"{type(done['err']).__name__}: {done['err']}\n")
            return 1
        return 0
class KernelBeatCommand(Program):
    def main(self):
        io = self.io
        io.write('Kernel beat in secs: ')
        io.write(str(self.syskernel.beat) + '\n')
        return 0
class PpmCommand(Program):
    def main(self):
        import urllib.request

        io = self.io
        fs = self.syskernel.fs

        def read_repo():
            try:
                text = fs.open_file('/etc/ppm.conf', 'r').read()
            except Exception:
                raise RuntimeError('no /etc/ppm.conf')
            for line in text.splitlines():
                line = line.strip()
                if line.startswith('repo='):
                    return line.split('=', 1)[1].strip().rstrip('/')
            raise RuntimeError('repo= not set in /etc/ppm.conf')

        io.write('ppm (add/remove/repo) = ')
        action = (yield from io.read_line()).strip().lower()

        if action == 'repo':
            try:
                io.write('current: ' + read_repo() + '\n')
            except Exception as e:
                io.write(str(e) + '\n')
            io.write('new repo (empty=keep) = ')
            new = (yield from io.read_line()).strip().rstrip('/')
            if new:
                fs.open_file('/etc/ppm.conf', 'w').write('repo=' + new + '\n')
                io.write('saved\n')
            return 0

        if action == 'remove':
            io.write('name = ')
            name = (yield from io.read_line()).strip()
            path = '/bin/' + name
            if not fs.exists_program(path):
                io.write('not installed: ' + name + '\n')
                return 1
            fs.delete_program(path)
            io.write('removed\n')
            return 0

        if action != 'add':
            io.write('use: add | remove | repo\n')
            return 1

        io.write('name = ')
        name = (yield from io.read_line()).strip()
        if not name or '/' in name or '\\' in name or '..' in name:
            io.write('invalid name\n')
            return 1

        try:
            repo = read_repo()
        except Exception as e:
            io.write(str(e) + '\n')
            return 1

        # папка в репо = ppm/
        url = repo + '/ppm/' + name + '.plus.py'
        io.write('fetch ' + url + '\n')

        try:
            with urllib.request.urlopen(url, timeout=15) as r:
                code = r.read().decode('utf-8')
        except Exception as e:
            io.write('error: ' + name + '.plus.py not found in repo\n(' + str(e) + ')\n')
            return 1

        if not code.strip():
            io.write('error: empty .plus.py\n')
            return 1

        try:
            fs.create_folder('/usr')
            fs.create_folder('/usr/packages')
        except Exception:
            pass
        fs.open_file('/usr/packages/' + name + '.plus.py', 'w').write(code)

        g = {'__name__': 'plus_mod', 'Program': Program}
        l = {}
        try:
            exec(code, g, l)
        except Exception as e:
            io.write('exec error: ' + str(e) + '\n')
            return 1

        ns = {**g, **l}
        cmd = ns.get('program_command') or name
        cls = ns.get('Main')
        if cls is None:
            io.write('error: class Main not found\n')
            return 1
        try:
            if not issubclass(cls, Program):
                io.write('error: Main must extend Program\n')
                return 1
        except TypeError:
            io.write('error: Main must be a class\n')
            return 1

        fs.write_program('/bin/' + str(cmd), cls)
        io.write('ok: /bin/' + str(cmd) + '\n')
        return 0
class BackgroundRecoveryThing(Program):
    def main(self):
        while True:
            fs = self.syskernel.fs
            if not fs.exists_program('/bin/console'):
                start = time()
                while not fs.exists_program('/bin/console'):
                    self.syskernel.status = 'recovery'
                    if time() - start > 5:
                        register_all_programs()
                    if time() - start > 7:
                        self.syskernel.status = 'dead'
                        yield
                        return 1
                    yield
                self.syskernel.status = 'ok'
            yield
XPPUI_PORT = 99


class XClient:
    """Клиент дисплея. В Program: XClient(self.syskernel, title=..., w=..., h=...)."""

    def __init__(self, syskernel, title="App", w=480, h=320, port=XPPUI_PORT):
        self.k = syskernel
        self.port = port
        self.title = title
        self.w = w
        self.h = h
        self.sock = None
        self._inbox = []
        self._rx = ""

    def connect(self):
        self.sock = self.k.socket("client", self.port)
        self._send({"t": "hello", "title": self.title, "w": self.w, "h": self.h})
        return self

    def _send(self, obj):
        if self.sock is None:
            return
        try:
            self.sock.send(json.dumps(obj, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def fill(self, r, g, b):
        self._send({"t": "fill", "r": int(r), "g": int(g), "b": int(b)})

    def text(self, x, y, s, c=(220, 220, 220)):
        self._send({"t": "text", "x": int(x), "y": int(y), "s": str(s), "c": list(c)})

    def rect(self, x, y, w, h, c=(255, 255, 255)):
        self._send({"t": "rect", "x": int(x), "y": int(y), "w": int(w), "h": int(h), "c": list(c)})

    def flip(self):
        self._send({"t": "flip"})

    def set_title(self, s):
        self.title = s
        self._send({"t": "title", "s": str(s)})

    def close(self):
        self._send({"t": "close"})
        try:
            if self.sock:
                self.sock.close()
        except Exception:
            pass
        self.sock = None

    def poll(self):
        """Неблокирующе: список событий."""
        if self.sock is None:
            return []
        while True:
            chunk = self.sock.read()
            if not chunk:
                break
            self._rx += chunk
        out = []
        while "\n" in self._rx:
            line, self._rx = self._rx.split("\n", 1)
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                pass
        return out


class _RemoteWin:
    def __init__(self, wid, sock):
        self.id = wid
        self.sock = sock
        self.title = "App"
        self.w, self.h = 400, 300
        self.surf = pg.Surface((self.w, self.h))
        self.surf.fill((0, 0, 0))
        self.pos = (50 + (wid * 24) % 200, 50 + (wid * 24) % 160)
        self.dragging = False
        self.drag_off = (0, 0)
        self.closed = False
        self._rx = ""

    def send(self, obj):
        try:
            self.sock.send(json.dumps(obj, ensure_ascii=False) + "\n")
        except Exception:
            self.closed = True

    def bar(self):
        return pg.Rect(self.pos[0], self.pos[1], self.w, 22)

    def body(self):
        return pg.Rect(self.pos[0], self.pos[1] + 22, self.w, self.h)

    def close_btn(self):
        b = self.bar()
        return pg.Rect(b.right - 22, b.y, 22, 22)

    def feed(self, chunk: str, font):
        self._rx += chunk
        while "\n" in self._rx:
            line, self._rx = self._rx.split("\n", 1)
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except Exception:
                continue
            t = msg.get("t")
            if t == "hello":
                self.title = str(msg.get("title", self.title))[:40]
                self.w = max(120, int(msg.get("w", self.w)))
                self.h = max(80, int(msg.get("h", self.h)))
                self.surf = pg.Surface((self.w, self.h))
                self.surf.fill((0, 0, 0))
            elif t == "fill":
                self.surf.fill((int(msg.get("r", 0)), int(msg.get("g", 0)), int(msg.get("b", 0))))
            elif t == "text":
                col = tuple(msg.get("c", [255, 255, 255]))[:3]
                s = str(msg.get("s", ""))[:100]
                self.surf.blit(font.render(s, True, col), (int(msg.get("x", 0)), int(msg.get("y", 0))))
            elif t == "rect":
                col = tuple(msg.get("c", [255, 255, 255]))[:3]
                pg.draw.rect(
                    self.surf,
                    col,
                    (int(msg["x"]), int(msg["y"]), int(msg["w"]), int(msg["h"])),
                )
            elif t == "title":
                self.title = str(msg.get("s", self.title))[:40]
            elif t == "close":
                self.closed = True
            elif t == "flip":
                pass


class XPPUi(Program):
    """Сервер окон :99 + панель снизу. Запуск первым."""

    def main(self):
        pg.init()
        info = pg.display.Info()
        W, H = max(800, info.current_w), max(600, info.current_h)
        sc = pg.display.set_mode((W, H))
        try:
            pg.display.toggle_fullscreen()
        except Exception:
            pass
        pg.display.set_caption("xPPUi")
        clk = pg.time.Clock()
        font = pg.font.SysFont("consolas", 16) or pg.font.SysFont(None, 16)
        tfont = pg.font.SysFont("Arial", 15) or font

        try:
            server = self.syskernel.socket("server", XPPUI_PORT)
        except OSError as e:
            # если io уходит в print — ок
            try:
                self.io.write(f"xPPUi: port {XPPUI_PORT} busy: {e}\n")
            except Exception:
                print(f"xPPUi: port busy: {e}")
            return 1

        wins = []
        next_id = 1
        accept_gen = server.accept()
        PANEL_H = 40
        launchers = [
            ("Console", "xConsole"),
            ("Calc", "xCalc"),
            ("Nan", "xNan"),
            ("Files", "xExplorer"),
        ]

        def try_accept():
            nonlocal accept_gen, next_id
            if accept_gen is None:
                accept_gen = server.accept()
            try:
                next(accept_gen)
            except StopIteration as e:
                sock = e.value
                w = _RemoteWin(next_id, sock)
                next_id += 1
                wins.append(w)
                w.send({"t": "ok", "id": w.id})
                accept_gen = server.accept()
            except Exception:
                accept_gen = server.accept()

        def focus(w):
            if w in wins:
                wins.remove(w)
                wins.append(w)
            for x in wins:
                x.send({"t": "focus", "on": 1 if x is w else 0})

        def spawn(cmd_name):
            fs = self.syskernel.fs
            path = "/bin/" + cmd_name
            if fs.exists_program(path):
                fs.run_program(path)

        run = True
        while run:
            try_accept()

            for w in list(wins):
                while True:
                    chunk = w.sock.read()
                    if not chunk:
                        break
                    w.feed(chunk, font)
                if w.sock._closed or (w.sock._peer and w.sock._peer._closed):
                    # ещё есть данные? feed уже вытащил
                    if not w.sock.read():
                        w.closed = True

            for e in pg.event.get():
                if e.type == pg.QUIT:
                    run = False
                elif e.type == pg.MOUSEBUTTONDOWN and e.button == 1:
                    mx, my = e.pos
                    # панель
                    if my >= H - PANEL_H:
                        x = 8
                        for label, cmd in launchers:
                            r = pg.Rect(x, H - PANEL_H + 6, 84, 28)
                            if r.collidepoint(mx, my):
                                spawn(cmd)
                                break
                            x += 92
                        x += 20
                        for i, w in enumerate(list(wins)):
                            r = pg.Rect(x, H - PANEL_H + 6, 100, 28)
                            if r.collidepoint(mx, my):
                                focus(w)
                                break
                            x += 108
                        continue
                    hit = None
                    for w in reversed(wins):
                        if w.close_btn().collidepoint(mx, my):
                            w.send({"t": "quit"})
                            w.closed = True
                            hit = w
                            break
                        if w.bar().collidepoint(mx, my):
                            w.dragging = True
                            w.drag_off = (mx - w.pos[0], my - w.pos[1])
                            hit = w
                            break
                        if w.body().collidepoint(mx, my):
                            lx = mx - w.pos[0]
                            ly = my - w.pos[1] - 22
                            w.send({"t": "mouse", "x": lx, "y": ly, "down": 1})
                            hit = w
                            break
                    if hit and not hit.closed:
                        focus(hit)
                elif e.type == pg.MOUSEBUTTONUP and e.button == 1:
                    for w in wins:
                        w.dragging = False
                elif e.type == pg.MOUSEMOTION:
                    for w in wins:
                        if w.dragging:
                            w.pos = (e.pos[0] - w.drag_off[0], e.pos[1] - w.drag_off[1])
                elif e.type == pg.KEYDOWN and wins:
                    top = wins[-1]
                    if e.key in (pg.K_RETURN, pg.K_BACKSPACE, pg.K_UP, pg.K_DOWN, pg.K_LEFT, pg.K_RIGHT, pg.K_ESCAPE):
                        top.send({"t": "key", "key": int(e.key), "char": ""})
                elif e.type == pg.TEXTINPUT and wins:
                    wins[-1].send({"t": "text", "s": e.text})

            wins = [w for w in wins if not w.closed]

            sc.fill((10, 16, 28))
            # panel
            pg.draw.rect(sc, (28, 32, 48), (0, H - PANEL_H, W, PANEL_H))
            pg.draw.line(sc, (80, 120, 200), (0, H - PANEL_H), (W, H - PANEL_H), 2)
            sc.blit(tfont.render(f"xPPUi  :{XPPUI_PORT}", True, (160, 190, 255)), (8, 8))
            x = 8
            for label, _cmd in launchers:
                r = pg.Rect(x, H - PANEL_H + 6, 84, 28)
                pg.draw.rect(sc, (50, 60, 90), r, border_radius=4)
                sc.blit(tfont.render(label, True, (230, 230, 255)), (x + 10, H - PANEL_H + 10))
                x += 92
            x += 20
            for w in wins:
                r = pg.Rect(x, H - PANEL_H + 6, 100, 28)
                active = wins and w is wins[-1]
                pg.draw.rect(sc, (60, 110, 80) if active else (40, 44, 60), r, border_radius=4)
                sc.blit(tfont.render((w.title or "app")[:12], True, (255, 255, 255)), (x + 8, H - PANEL_H + 10))
                x += 108

            for w in wins:
                pg.draw.rect(sc, (220, 220, 230), w.bar())
                sc.blit(tfont.render(w.title[:50], True, (0, 0, 0)), (w.pos[0] + 6, w.pos[1] + 2))
                pg.draw.rect(sc, (200, 50, 50), w.close_btn())
                sc.blit(w.surf, w.body().topleft)

            pg.display.flip()
            clk.tick(30)
            yield

        for w in wins:
            w.send({"t": "quit"})
            try:
                w.sock.close()
            except Exception:
                pass
        try:
            server.close()
        except Exception:
            pass
        pg.display.quit()
        return 0


# ---------- apps ----------

class xConsole(Program):
    """Настоящий PPLUSConsole в окне xPPUi 800x600 (логика как PPUi)."""

    def main(self):
        import pygame as pg

        xc = XClient(self.syskernel, "xConsole", 800, 600)
        try:
            xc.connect()
        except ConnectionRefusedError:
            self.io.write("xPPUi not running\n")
            return 1

        # --- те же размеры текста, что в PPUi, под 800x600 ---
        font_size = 18
        line_h = font_size + 4
        max_lines = max(1, (600 - 20) // line_h - 1)
        max_chars = max(10, (800 - 20) // 10)  # ~10 px на символ consolas-ish

        lines = []
        buf = ""
        pending = ""

        def add_line(text):
            text = str(text)
            if "\033[2J" in text:
                lines.clear()
                text = text.replace("\033[2J", "").replace("\033[H", "")
            if not text and not lines:
                return
            while text is not None:
                if len(text) <= max_chars:
                    lines.append(text)
                    break
                lines.append(text[:max_chars])
                text = text[max_chars:]
            while len(lines) > max_lines:
                lines.pop(0)

        def gui_write(text):
            nonlocal pending
            pending += str(text)
            while "\n" in pending:
                line, pending = pending.split("\n", 1)
                add_line(line)

        # КАК В PPUi: патч класса — все print/write программ идут сюда
        original_write = IO.write

        def patched_write(self, text):
            gui_write(text)

        IO.write = patched_write

        console = self.syskernel.create_process(PPLUSConsole, capture_input=False)

        def redraw():
            xc.fill(0, 0, 0)
            y = 8
            for line in lines:
                visible = line.replace("\033[2J", "").replace("\033[H", "").replace("\t", "│")
                xc.text(8, y, visible[:max_chars], (255, 255, 255))
                y += line_h
            current = (pending + buf + "█")[-max_chars:]
            xc.text(8, y, current.replace("\t", "│"), (255, 255, 255))
            xc.flip()

        try:
            while not console.finished:
                for e in xc.poll():
                    t = e.get("t")
                    if t in ("quit", "close"):
                        console.finished = True
                        break

                    if t == "text":
                        ch = e.get("s", "")
                        if ch and ch.isprintable():
                            buf += ch

                    if t == "key":
                        k = e.get("key")
                        # Enter
                        if k in (pg.K_RETURN, pg.K_KP_ENTER):
                            if console.io.is_reading():
                                console.io.send(buf)
                            gui_write(buf + "\n")
                            buf = ""
                        elif k == pg.K_BACKSPACE:
                            buf = buf[:-1]
                        elif k == pg.K_TAB:
                            buf += "\t"
                        # Ctrl не приходит с xPPUi отдельно — хоткеи _x шлём как text/key с сервера при необходимости

                redraw()
                yield
        finally:
            IO.write = original_write
            xc.close()

        return console.exit_code if console.exit_code is not None else 0

class xCalc(Program):
    def main(self):
        xc = XClient(self.syskernel, "xCalc", 320, 200)
        try:
            xc.connect()
        except ConnectionRefusedError:
            self.io.write("xPPUi not running\n")
            return 1
        expr = ""
        hist = []

        def redraw():
            xc.fill(24, 28, 36)
            xc.text(10, 10, "xCalc", (255, 220, 120))
            y = 40
            for h in hist[-4:]:
                xc.text(10, y, h[:36], (180, 180, 180))
                y += 20
            xc.text(10, 160, expr + "_", (255, 255, 255))
            xc.flip()

        redraw()
        while True:
            for e in xc.poll():
                t = e.get("t")
                if t in ("quit", "close"):
                    xc.close()
                    return 0
                if t == "text":
                    ch = e.get("s", "")
                    if ch in "0123456789+-*/().% ":
                        expr += ch
                if t == "key":
                    k = e.get("key")
                    if k == pg.K_BACKSPACE:
                        expr = expr[:-1]
                    elif k == pg.K_RETURN:
                        try:
                            if any(c not in "0123456789+-*/().% eE " for c in expr):
                                raise ValueError("bad")
                            val = eval(expr, {"__builtins__": {}}, {})
                            hist.append(f"{expr} = {val}")
                        except Exception:
                            hist.append(expr + " = error")
                        expr = ""
            redraw()
            yield


class xNan(Program):
    """Блокнот + проводник Открыть/Сохранить."""

    def main(self):
        import pygame as pg

        W, H = 800, 600
        xc = XClient(self.syskernel, "xNan", W, H)
        fs=self.syskernel.fs
        try:
            xc.connect()
            path = "/tmp/notes.txt"
            try:
                if fs.exists_file("/tmp/.xnan_open"):
                    print('xNan detected .xnan_open')
                    p = fs.open_file("/tmp/.xnan_open", "r").read().strip()
                    if p:
                        path = p
                    # можно удалить маркер
                    try:
                        fs.delete_file("/tmp/.xnan_open")
                    except Exception:
                        print('error deleting file')
            except Exception:
                print('error')
            # дальше load_file(path)
        except ConnectionRefusedError:
            self.io.write("xPPUi not running\n")
            return 1

        fs = self.syskernel.fs
        lines = [""]
        cy = cx = scroll = 0
        MENU_H, STATUS_H, line_h = 28, 22, 20
        body_lines = max(1, (H - MENU_H - STATUS_H - 8) // line_h)
        max_chars = 86

        menu_open = None
        status = "Готово"
        modified = False
        clip = ""

        # dialog
        mode = "edit"  # edit | pick | confirm | mkdir | namefile
        pick_kind = "open"  # open | save
        pick_cwd = "/tmp"
        pick_sel = 0
        pick_scroll = 0
        name_buf = ""
        confirm_action = None  # "new"

        menu_items = [("file", "Файл", 8), ("edit", "Правка", 70), ("exit", "Выход", 150)]
        file_menu = ["Новый", "Открыть…", "Сохранить", "Сохранить как…"]
        edit_menu = ["Вырезать строку", "Копировать строку", "Вставить строку", "Удалить строку"]

        def listing(cwd):
            out = [("..", "up")]
            try:
                if cwd == "/":
                    folder = fs.root
                else:
                    parent, name = fs._resolve(cwd)
                    folder = None
                    for item in parent.files:
                        if isinstance(item, Folder) and item.name == name:
                            folder = item
                            break
                    if folder is None:
                        return out
                for item in folder.files:
                    if isinstance(item, Folder):
                        out.append((item.name, "dir"))
                    elif not hasattr(item, "program_class"):
                        out.append((item.name, "file"))
                out.sort(key=lambda x: (0 if x[1] == "up" else 1 if x[1] == "dir" else 2, x[0].lower()))
            except Exception:
                pass
            return out

        def join_path(cwd, name):
            if cwd == "/":
                return "/" + name
            return cwd.rstrip("/") + "/" + name

        def load_file(p):
            nonlocal lines, cy, cx, scroll, path, modified, status
            path = p
            try:
                if fs.exists_file(p):
                    text = fs.open_file(p, "r").read()
                    lines = text.split("\n") or [""]
                else:
                    lines = [""]
                    fs.open_file(p, "w").write("")
                cy = cx = scroll = 0
                modified = False
                status = f"Открыт {p}"
            except Exception as e:
                status = f"Ошибка: {e}"

        def save_to(p=None):
            nonlocal path, modified, status
            if p:
                path = p
            try:
                parent = "/".join(path.strip("/").split("/")[:-1])
                if parent:
                    try:
                        fs.create_folder("/" + parent)
                    except Exception:
                        pass
                fs.open_file(path, "w").write("\n".join(lines))
                modified = False
                status = f"Сохранено {path}"
                return True
            except Exception as e:
                status = f"Ошибка: {e}"
                return False

        def ensure_cursor():
            nonlocal cy, cx, scroll
            cy = max(0, min(cy, len(lines) - 1))
            cx = max(0, min(cx, len(lines[cy])))
            if cy < scroll:
                scroll = cy
            if cy >= scroll + body_lines:
                scroll = cy - body_lines + 1

        def insert_text(s):
            nonlocal cx, modified, status
            lines[cy] = lines[cy][:cx] + s + lines[cy][cx:]
            cx += len(s)
            modified = True
            status = "Изменено"

        def open_pick(kind):
            nonlocal mode, pick_kind, pick_cwd, pick_sel, pick_scroll, menu_open
            mode = "pick"
            pick_kind = kind
            pick_cwd = "/".join(path.strip("/").split("/")[:-1])
            if not pick_cwd:
                pick_cwd = "/"
            else:
                pick_cwd = "/" + pick_cwd
            pick_sel = 0
            pick_scroll = 0
            menu_open = None

        def redraw():
            ensure_cursor()
            xc.fill(32, 32, 36)

            if mode == "edit":
                xc.rect(0, 0, W, MENU_H, (240, 240, 240))
                for mid, label, mx in menu_items:
                    xc.text(mx, 6, label, (0, 0, 0))
                if menu_open == "file":
                    xc.rect(8, MENU_H, 170, 24 * len(file_menu), (250, 250, 250))
                    for i, name in enumerate(file_menu):
                        xc.text(14, MENU_H + 4 + i * 24, name, (0, 0, 0))
                if menu_open == "edit":
                    xc.rect(70, MENU_H, 190, 24 * len(edit_menu), (250, 250, 250))
                    for i, name in enumerate(edit_menu):
                        xc.text(76, MENU_H + 4 + i * 24, name, (0, 0, 0))

                y = MENU_H + 4
                for i in range(body_lines):
                    idx = scroll + i
                    if idx >= len(lines):
                        break
                    shown = lines[idx]
                    if idx == cy:
                        shown = shown[:cx] + "█" + shown[cx:]
                    col = (220, 255, 220) if idx == cy else (230, 230, 230)
                    xc.text(6, y, f"{idx+1:4}| {shown}"[:max_chars], col)
                    y += line_h

            elif mode == "pick":
                title = "Открыть" if pick_kind == "open" else "Сохранить как"
                xc.rect(40, 40, W - 80, H - 100, (245, 245, 248))
                xc.text(56, 52, f"{title}  —  {pick_cwd}", (0, 0, 0))
                xc.text(56, 74, "Enter: открыть/выбрать   N: новый файл   M: папка   Esc: отмена", (60, 60, 80))
                entries = listing(pick_cwd)
                vis = 16
                y = 100
                for i in range(vis):
                    idx = pick_scroll + i
                    if idx >= len(entries):
                        break
                    name, kind = entries[idx]
                    mark = "/" if kind in ("dir", "up") else " "
                    pre = ">" if idx == pick_sel else " "
                    col = (0, 80, 0) if idx == pick_sel else (20, 20, 20)
                    xc.text(60, y, f"{pre} {name}{mark}"[:70], col)
                    y += 22
                xc.text(56, H - 80, "Подсказка: выбери файл или папку", (80, 80, 100))

            elif mode == "confirm":
                xc.rect(120, 180, W - 240, 160, (250, 240, 240))
                xc.text(150, 200, "Вы уверены?", (180, 0, 0))
                xc.text(150, 230, "Старые данные не будут сохранены.", (40, 40, 40))
                xc.text(150, 270, "[Y] Да, новый файл     [N] Отмена", (0, 0, 0))

            elif mode in ("mkdir", "namefile"):
                xc.rect(120, 180, W - 240, 140, (245, 245, 250))
                label = "Имя папки:" if mode == "mkdir" else "Имя файла:"
                xc.text(150, 200, label, (0, 0, 0))
                xc.text(150, 235, name_buf + "█", (0, 100, 0))
                xc.text(150, 280, "Enter — создать   Esc — отмена", (80, 80, 80))

            xc.rect(0, H - STATUS_H, W, STATUS_H, (50, 50, 55))
            mark = "*" if modified else " "
            xc.text(
                8,
                H - STATUS_H + 3,
                f"{mark} {path}  |  {cy+1}:{cx+1}  |  {status}",
                (180, 180, 190),
            )
            xc.flip()

        def pick_activate():
            nonlocal pick_cwd, pick_sel, pick_scroll, mode, path, status
            entries = listing(pick_cwd)
            if not entries:
                return
            name, kind = entries[pick_sel]
            if kind == "up":
                if pick_cwd != "/":
                    parts = pick_cwd.strip("/").split("/")
                    pick_cwd = "/" + "/".join(parts[:-1]) if len(parts) > 1 else "/"
                    pick_sel = pick_scroll = 0
                return
            if kind == "dir":
                pick_cwd = join_path(pick_cwd, name)
                pick_sel = pick_scroll = 0
                return
            # file
            full = join_path(pick_cwd, name)
            if pick_kind == "open":
                load_file(full)
                mode = "edit"
            else:
                if save_to(full):
                    mode = "edit"

        load_file(path)

        while True:
            for e in xc.poll():
                t = e.get("t")
                if t in ("quit", "close"):
                    if modified:
                        save_to()
                    xc.close()
                    return 0

                # ----- confirm new -----
                if mode == "confirm":
                    if t == "text":
                        ch = (e.get("s") or "").lower()
                        if ch == "y":
                            lines[:] = [""]
                            cy = cx = scroll = 0
                            path = "/tmp/notes.txt"
                            modified = False
                            status = "Новый файл"
                            mode = "edit"
                            confirm_action = None
                        elif ch == "n":
                            mode = "edit"
                            status = "Отменено"
                    if t == "key" and e.get("key") == pg.K_ESCAPE:
                        mode = "edit"
                    continue

                # ----- mkdir / namefile -----
                if mode in ("mkdir", "namefile"):
                    if t == "text":
                        ch = e.get("s", "")
                        if ch.isprintable() and ch not in "/\\":
                            name_buf += ch
                    if t == "key":
                        k = e.get("key")
                        if k == pg.K_BACKSPACE:
                            name_buf = name_buf[:-1]
                        elif k == pg.K_ESCAPE:
                            mode = "pick"
                            name_buf = ""
                        elif k == pg.K_RETURN and name_buf.strip():
                            full = join_path(pick_cwd, name_buf.strip())
                            try:
                                if mode == "mkdir":
                                    fs.create_folder(full)
                                    status = f"Папка {full}"
                                    mode = "pick"
                                else:
                                    if not full.endswith(".txt") and "." not in name_buf:
                                        full += ".txt"
                                    if pick_kind == "save":
                                        save_to(full)
                                        mode = "edit"
                                    else:
                                        load_file(full)
                                        mode = "edit"
                            except Exception as ex:
                                status = str(ex)
                                mode = "pick"
                            name_buf = ""
                    continue

                # ----- file picker -----
                if mode == "pick":
                    entries = listing(pick_cwd)
                    if t == "key":
                        k = e.get("key")
                        if k == pg.K_UP:
                            pick_sel = max(0, pick_sel - 1)
                            if pick_sel < pick_scroll:
                                pick_scroll = pick_sel
                        elif k == pg.K_DOWN:
                            pick_sel = min(len(entries) - 1, pick_sel + 1)
                            if pick_sel >= pick_scroll + 16:
                                pick_scroll = pick_sel - 15
                        elif k == pg.K_RETURN:
                            pick_activate()
                        elif k == pg.K_ESCAPE:
                            mode = "edit"
                            status = "Отменено"
                    if t == "text":
                        ch = (e.get("s") or "").lower()
                        if ch == "n":
                            mode = "namefile"
                            name_buf = ""
                        elif ch == "m":
                            mode = "mkdir"
                            name_buf = ""
                    if t == "mouse" and e.get("down") == 1:
                        mx, my = int(e.get("x", 0)), int(e.get("y", 0))
                        if 100 <= my <= 100 + 16 * 22:
                            i = (my - 100) // 22 + pick_scroll
                            if 0 <= i < len(entries):
                                pick_sel = i
                                pick_activate()
                    continue

                # ----- edit mode -----
                if t == "mouse" and e.get("down") == 1:
                    mx, my = int(e.get("x", 0)), int(e.get("y", 0))
                    if my < MENU_H:
                        if 8 <= mx <= 55:
                            menu_open = None if menu_open == "file" else "file"
                        elif 70 <= mx <= 130:
                            menu_open = None if menu_open == "edit" else "edit"
                        elif 150 <= mx <= 210:
                            save_to()
                            xc.close()
                            return 0
                        else:
                            menu_open = None
                    elif menu_open == "file" and 8 <= mx <= 178:
                        i = (my - MENU_H) // 24
                        menu_open = None
                        if i == 0:
                            if modified:
                                mode = "confirm"
                                confirm_action = "new"
                            else:
                                lines[:] = [""]
                                cy = cx = scroll = 0
                                path = "/tmp/notes.txt"
                                status = "Новый файл"
                        elif i == 1:
                            open_pick("open")
                        elif i == 2:
                            save_to()
                        elif i == 3:
                            open_pick("save")
                    elif menu_open == "edit" and 70 <= mx <= 260:
                        i = (my - MENU_H) // 24
                        menu_open = None
                        if i == 0:
                            clip = lines[cy]
                            lines[cy] = ""
                            modified = True
                        elif i == 1:
                            clip = lines[cy]
                            status = "Скопировано"
                        elif i == 2:
                            insert_text(clip)
                        elif i == 3:
                            if len(lines) > 1:
                                lines.pop(cy)
                                cy = min(cy, len(lines) - 1)
                            else:
                                lines[0] = ""
                            modified = True
                    elif menu_open:
                        menu_open = None
                    elif MENU_H <= my < H - STATUS_H:
                        row = scroll + (my - MENU_H - 4) // line_h
                        if 0 <= row < len(lines):
                            cy = row
                            cx = min(len(lines[cy]), max(0, (mx - 50) // 9))

                if menu_open:
                    if t == "key" and e.get("key") == pg.K_ESCAPE:
                        menu_open = None
                    continue

                if t == "text":
                    s = e.get("s", "")
                    if s and s.isprintable():
                        insert_text(s)

                if t == "key":
                    k = e.get("key")
                    if k == pg.K_BACKSPACE:
                        if cx > 0:
                            lines[cy] = lines[cy][: cx - 1] + lines[cy][cx:]
                            cx -= 1
                            modified = True
                        elif cy > 0:
                            prev = lines[cy - 1]
                            cur = lines.pop(cy)
                            cy -= 1
                            cx = len(prev)
                            lines[cy] = prev + cur
                            modified = True
                    elif k == pg.K_RETURN:
                        rest = lines[cy][cx:]
                        lines[cy] = lines[cy][:cx]
                        lines.insert(cy + 1, rest)
                        cy += 1
                        cx = 0
                        modified = True
                    elif k == pg.K_UP:
                        cy = max(0, cy - 1)
                    elif k == pg.K_DOWN:
                        cy = min(len(lines) - 1, cy + 1)
                    elif k == pg.K_LEFT:
                        if cx > 0:
                            cx -= 1
                        elif cy > 0:
                            cy -= 1
                            cx = len(lines[cy])
                    elif k == pg.K_RIGHT:
                        if cx < len(lines[cy]):
                            cx += 1
                        elif cy < len(lines) - 1:
                            cy += 1
                            cx = 0
                    elif k == pg.K_PAGEUP:
                        cy = max(0, cy - body_lines)
                    elif k == pg.K_PAGEDOWN:
                        cy = min(len(lines) - 1, cy + body_lines)
                    elif k == pg.K_HOME:
                        cx = 0
                    elif k == pg.K_END:
                        cx = len(lines[cy])
                    ensure_cursor()

            redraw()
            yield


class xExplorer(Program):
    """
    Проводник:
      Enter — открыть папку / файл в xNan / program*
      E — редактировать в xNan
      T — если .py → новое окно: dotpy со скриптом (через xConsole-паттерн)
      N — новый файл    M — новая папка
      D — удалить       R — обновить
      Backspace — вверх
    """

    def main(self):
        import pygame as pg

        W, H = 640, 480
        xc = XClient(self.syskernel, "xExplorer", W, H)
        try:
            xc.connect()
        except ConnectionRefusedError:
            self.io.write("xPPUi not running\n")
            return 1

        fs = self.syskernel.fs
        cwd = "/"
        sel = 0
        scroll = 0
        VIS = 16
        status = "E:edit  N:file  M:dir  D:del  T:dotpy  Enter:open"
        mode = "list"  # list | namefile | mkdir | confirm_del
        name_buf = ""
        del_target = None

        def listing():
            out = []
            if cwd != "/":
                out.append(("..", "up"))
            try:
                if cwd == "/":
                    folder = fs.root
                else:
                    parent, name = fs._resolve(cwd)
                    folder = next(
                        (i for i in parent.files if isinstance(i, Folder) and i.name == name),
                        None,
                    )
                    if folder is None:
                        return out + [("(error)", "err")]
                for item in folder.files:
                    if isinstance(item, Folder):
                        out.append((item.name, "dir"))
                    elif hasattr(item, "program_class"):
                        out.append((item.name, "prog"))
                    else:
                        out.append((item.name, "file"))
                out.sort(
                    key=lambda x: (
                        0 if x[1] == "up" else 1 if x[1] == "dir" else 2 if x[1] == "prog" else 3,
                        x[0].lower(),
                    )
                )
            except Exception as e:
                out.append((str(e), "err"))
            return out

        def join(name):
            return ("/" + name) if cwd == "/" else cwd.rstrip("/") + "/" + name

        def ensure_sel(entries):
            nonlocal sel, scroll
            if not entries:
                sel = 0
                return
            sel = max(0, min(sel, len(entries) - 1))
            if sel < scroll:
                scroll = sel
            if sel >= scroll + VIS:
                scroll = sel - VIS + 1

        def spawn_program(cmd: str):
            path = "/bin/" + cmd
            if fs.exists_program(path):
                fs.run_program(path)
                return True
            return False

        def open_in_nan(filepath: str):
            """Запуск xNan; путь кладём в /tmp/.xnan_open чтобы nan подхватил (см. ниже)."""
            try:
                fs.open_file("/tmp/.xnan_open", "w").write(filepath)
            except Exception:
                pass
            if not spawn_program("xNan"):
                status = "xNan not in /bin"

        def run_dotpy_script(filepath: str):
            """
            Новое «окно»: xDotpy — тонкая обёртка (ниже).
            Путь скрипта в /tmp/.dotpy_run
            """
            try:
                fs.open_file("/tmp/.dotpy_run", "w").write(filepath)
            except Exception:
                pass
            if fs.exists_program("/bin/xDotpy"):
                fs.run_program("/bin/xDotpy")
            elif fs.exists_program("/bin/dotpy"):
                # без окна — в текущей консоли не выйдет; нужен xDotpy
                status = "install xDotpy for windowed run"
            else:
                status = "no xDotpy/dotpy"

        def run_prog_file(name: str):
            full = join(name)
            # program в текущей папке
            try:
                parent, nm = fs._resolve(full)
                for item in parent.files:
                    if getattr(item, "name", None) == nm and hasattr(item, "program_class"):
                        self.syskernel.create_process(item.program_class, capture_input=False)
                        return
            except Exception as e:
                status = str(e)
            # или /bin/name
            if fs.exists_program("/bin/" + name):
                fs.run_program("/bin/" + name)

        def do_delete(full, kind):
            nonlocal status
            try:
                if kind == "dir":
                    fs.delete_folder(full)
                elif kind == "prog":
                    fs.delete_program(full)
                else:
                    fs.delete_file(full)
                status = f"deleted {full}"
            except Exception as e:
                status = str(e)

        def redraw(entries):
            xc.fill(16, 18, 24)
            xc.text(8, 6, f"xExplorer  {cwd}", (120, 180, 255))
            xc.text(8, 26, status[:70], (140, 150, 160))
            y = 50
            for i in range(VIS):
                idx = scroll + i
                if idx >= len(entries):
                    break
                name, kind = entries[idx]
                mark = {"dir": "/", "up": "/", "prog": "*", "file": " ", "err": "!"}.get(kind, " ")
                col = (255, 255, 120) if idx == sel else (210, 210, 210)
                if kind == "dir" or kind == "up":
                    col = (120, 200, 255) if idx != sel else (255, 255, 120)
                if kind == "prog":
                    col = (180, 255, 180) if idx != sel else (255, 255, 120)
                pre = ">" if idx == sel else " "
                xc.text(12, y, f"{pre} {name}{mark}"[:70], col)
                y += 20

            if mode == "namefile":
                xc.rect(80, 180, 480, 100, (40, 44, 60))
                xc.text(100, 200, "Имя файла:", (255, 255, 255))
                xc.text(100, 230, name_buf + "█", (180, 255, 180))
            elif mode == "mkdir":
                xc.rect(80, 180, 480, 100, (40, 44, 60))
                xc.text(100, 200, "Имя папки:", (255, 255, 255))
                xc.text(100, 230, name_buf + "█", (180, 255, 180))
            elif mode == "confirm_del":
                xc.rect(80, 180, 480, 120, (60, 30, 30))
                xc.text(100, 200, "Удалить?", (255, 100, 100))
                xc.text(100, 230, str(del_target), (255, 220, 220))
                xc.text(100, 260, "[Y] да   [N] нет", (255, 255, 255))

            xc.text(8, H - 24, "Enter open  E edit  T py  N file  M dir  D del", (100, 110, 130))
            xc.flip()

        entries = listing()
        redraw(entries)

        while True:
            entries = listing()
            ensure_sel(entries)

            for e in xc.poll():
                t = e.get("t")
                if t in ("quit", "close"):
                    xc.close()
                    return 0

                # --- диалоги ---
                if mode in ("namefile", "mkdir"):
                    if t == "text":
                        ch = e.get("s", "")
                        if ch.isprintable() and ch not in "/\\":
                            name_buf += ch
                    if t == "key":
                        k = e.get("key")
                        if k == pg.K_BACKSPACE:
                            name_buf = name_buf[:-1]
                        elif k == pg.K_ESCAPE:
                            mode = "list"
                            name_buf = ""
                        elif k == pg.K_RETURN and name_buf.strip():
                            full = join(name_buf.strip())
                            try:
                                if mode == "mkdir":
                                    fs.create_folder(full)
                                    status = f"mkdir {full}"
                                else:
                                    if fs.exists_file(full):
                                        status = "already exists"
                                    else:
                                        fs.open_file(full, "w").write("")
                                        status = f"created {full}"
                                        open_in_nan(full)
                            except Exception as ex:
                                status = str(ex)
                            mode = "list"
                            name_buf = ""
                    continue

                if mode == "confirm_del":
                    if t == "text":
                        ch = (e.get("s") or "").lower()
                        if ch == "y" and del_target:
                            do_delete(del_target[0], del_target[1])
                            mode = "list"
                            del_target = None
                        elif ch == "n":
                            mode = "list"
                            status = "cancel"
                    if t == "key" and e.get("key") == pg.K_ESCAPE:
                        mode = "list"
                    continue

                # --- список ---
                if t == "key":
                    k = e.get("key")
                    if k == pg.K_UP:
                        sel = max(0, sel - 1)
                    elif k == pg.K_DOWN:
                        sel = min(len(entries) - 1, sel + 1)
                    elif k == pg.K_PAGEUP:
                        sel = max(0, sel - VIS)
                    elif k == pg.K_PAGEDOWN:
                        sel = min(len(entries) - 1, sel + VIS)
                    elif k == pg.K_BACKSPACE:
                        if cwd != "/":
                            parts = cwd.strip("/").split("/")
                            cwd = "/" + "/".join(parts[:-1]) if len(parts) > 1 else "/"
                            sel = 0
                    elif k == pg.K_RETURN and entries:
                        name, kind = entries[sel]
                        if kind == "up":
                            if cwd != "/":
                                parts = cwd.strip("/").split("/")
                                cwd = "/" + "/".join(parts[:-1]) if len(parts) > 1 else "/"
                                sel = 0
                        elif kind == "dir":
                            cwd = join(name)
                            sel = 0
                        elif kind == "prog":
                            run_prog_file(name)
                            status = f"run {name}"
                        elif kind == "file":
                            if name.endswith(".py"):
                                run_dotpy_script(join(name))
                                status = f"dotpy {name}"
                            else:
                                open_in_nan(join(name))
                                status = f"edit {name}"

                if t == "text":
                    ch = (e.get("s") or "").lower()
                    if ch == "e" and entries:
                        name, kind = entries[sel]
                        if kind == "file":
                            open_in_nan(join(name))
                            status = f"xNan {name}"
                        else:
                            status = "only files"
                    elif ch == "n":
                        mode = "namefile"
                        name_buf = ""
                    elif ch == "m":
                        mode = "mkdir"
                        name_buf = ""
                    elif ch == "d" and entries:
                        name, kind = entries[sel]
                        if kind in ("file", "dir", "prog"):
                            del_target = (join(name), kind)
                            mode = "confirm_del"
                    elif ch == "t" and entries:
                        name, kind = entries[sel]
                        if kind == "file" and name.endswith(".py"):
                            run_dotpy_script(join(name))
                            status = f"dotpy {name}"
                        else:
                            status = "only .py"
                    elif ch == "r":
                        status = "refreshed"

            redraw(listing())
            yield
class xDemo(Program):
    """Пример клиента xPPUi. Запуск: сначала xppui, потом xDemo."""

    def main(self):
        import pygame as pg

        xc = XClient(self.syskernel, title="xDemo", w=400, h=300)
        try:
            xc.connect()
        except ConnectionRefusedError:
            self.io.write("Сначала запусти xppui\n")
            return 1

        buf = ""
        clicks = 0

        while True:
            # --- рисуем кадр ---
            xc.fill(30, 40, 60)
            xc.text(16, 16, "Пример xPPUi-клиента", (120, 220, 255))
            xc.text(16, 48, "Печатай текст, Enter — очистить", (200, 200, 200))
            xc.text(16, 80, "Клики мыши: " + str(clicks), (255, 220, 120))
            xc.rect(16, 120, 368, 40, (40, 50, 70))
            xc.text(24, 130, buf + "█", (255, 255, 255))
            xc.text(16, 260, "Esc / крестик — выход", (140, 140, 160))
            xc.flip()

            # --- события (неблокирующе) ---
            for e in xc.poll():
                t = e.get("t")

                if t in ("quit", "close"):
                    xc.close()
                    return 0

                if t == "text":
                    ch = e.get("s", "")
                    if ch.isprintable():
                        buf += ch

                if t == "key":
                    k = e.get("key")
                    if k == pg.K_BACKSPACE:
                        buf = buf[:-1]
                    elif k in (pg.K_RETURN, pg.K_KP_ENTER):
                        buf = ""
                    elif k == pg.K_ESCAPE:
                        xc.close()
                        return 0

                if t == "mouse" and e.get("down") == 1:
                    clicks += 1
                    # e["x"], e["y"] — координаты внутри окна

            yield
class xDotpy(Program):
    """Окно: запускает /bin/dotpy со скриптом из /tmp/.dotpy_run."""

    def main(self):
        import pygame as pg

        xc = XClient(self.syskernel, "xDotpy", 700, 450)
        try:
            xc.connect()
        except ConnectionRefusedError:
            self.io.write("xPPUi not running\n")
            return 1

        script = "/tmp/script.py"
        try:
            if self.syskernel.fs.exists_file("/tmp/.dotpy_run"):
                script = self.syskernel.fs.open_file("/tmp/.dotpy_run", "r").read().strip() or script
        except Exception:
            pass

        lines, pending, buf = [], "", ""
        max_lines, max_chars = 18, 80

        def add_line(text):
            text = str(text)
            while text is not None:
                if len(text) <= max_chars:
                    lines.append(text)
                    break
                lines.append(text[:max_chars])
                text = text[max_chars:]
            while len(lines) > max_lines:
                lines.pop(0)

        def gui_write(text):
            nonlocal pending
            pending += str(text)
            while "\n" in pending:
                line, pending = pending.split("\n", 1)
                add_line(line)

        original = IO.write

        def patched(self, text):
            gui_write(text)

        IO.write = patched

        if not self.syskernel.fs.exists_program("/bin/dotpy"):
            IO.write = original
            self.io.write("no /bin/dotpy\n")
            xc.close()
            return 1

        pio = self.syskernel.fs.run_program("/bin/dotpy")
        # ждём read_line (script =) и шлём путь
        sent = False

        def redraw():
            xc.fill(12, 14, 18)
            y = 6
            for line in lines[-max_lines:]:
                xc.text(6, y, line[:max_chars], (180, 255, 180))
                y += 18
            cur = (pending + buf + "█")[-max_chars:]
            xc.text(6, y, cur, (200, 255, 200))
            xc.flip()

        try:
            while True:
                proc = None
                for p in self.syskernel.processes:
                    if p.io is pio:
                        proc = p
                        break
                if proc is None or proc.finished:
                    break

                if not sent and pio.is_reading():
                    pio.send(script)
                    gui_write(script + "\n")
                    sent = True

                for e in xc.poll():
                    t = e.get("t")
                    if t in ("quit", "close"):
                        if proc:
                            proc.finished = True
                        xc.close()
                        return 0
                    if not pio.is_reading():
                        continue
                    if t == "text":
                        buf += e.get("s", "")
                    if t == "key":
                        k = e.get("key")
                        if k == pg.K_BACKSPACE:
                            buf = buf[:-1]
                        elif k in (pg.K_RETURN, pg.K_KP_ENTER):
                            pio.send(buf)
                            gui_write(buf + "\n")
                            buf = ""
                redraw()
                yield
        finally:
            IO.write = original
            xc.close()
        return 0
print('Writing programs.')
def register_all_programs():
    create_program('tree', TreeCommand)
    create_program('ls', LsCommand)
    create_program('mkdir', MkdirCommand)
    create_program('wf', WriteFileCommand)
    create_program('rf', ReadFileCommand)
    create_program('df', RmCommand)
    create_program('echo', EchoCommand)
    create_program('empty', ClearCommand)
    create_program('help', HelpCommand)
    create_program('ps', PsCommand)
    create_program('console', PPLUSConsole)
    create_program('python3', Python3Command)
    create_program('ppui', PPUi)
    create_program('sl', WaitCommand)
    create_program('sbroadcast', BoardcastSocket)
    create_program('srawread', RawReadSocket)
    create_program('st', StopTaskCommand)
    create_program('res', Restart)
    create_program('faf', FafCommand)
    create_program('nan', NanoCommand)
    create_program('save', SaveCommand)
    create_program('load', LoadCommand)
    create_program('dotpy', DotPyCommand)
    create_program('beat', KernelBeatCommand)
    create_program('ppm', PpmCommand)
    create_program('xppui', XPPUi)
    create_program('xConsole', xConsole)
    create_program('xCalc', xCalc)
    create_program('xNan', xNan)
    create_program('xExplorer', xExplorer)
    create_program('xDemo', xDemo)
    create_program('xDotpy', xDotpy)
print('Done!')
if __name__ == '__main__':
    mode = input('mode 0=PPUi 1=PPtcp 2=xPPUi: ')
    if mode == '0':
        kernel.create_process(BackgroundRecoveryThing, capture_input=False)
        kernel.create_process(LoadCommand, capture_input=False)
        kernel.create_process(PPUi, capture_input=False)
        kernel.boot()
    if mode == '1':
        kernel.create_process(PPtcp, capture_input=False)
        kernel.boot()
    if mode == '2':
        kernel.create_process(LoadCommand, capture_input=False)
        kernel.create_process(BackgroundRecoveryThing, capture_input=False)
        kernel.create_process(XPPUi, capture_input=False)
        kernel.boot()